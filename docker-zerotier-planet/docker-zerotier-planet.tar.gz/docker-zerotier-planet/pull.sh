git checkout .
git pull
