#!/bin/bash 
# debain ubuntu自动并设置的为planet服务器
# 多台台服务器请手动修改mkworld.cpp 下面的 Miami 代码
# addr服务器公网ip+port
# apt autoremove
apt update -y
apt install curl -y
apt-get -y install build-essential
apt-get install git -y
ip=`wget http://ipecho.net/plain -O - -q ; echo`
addr=$ip/9993       # 端口号9993替换你ztncui所设置的
cd /root/planet/attic/world
identity=`cat /home/zerotier/var/lib/zerotier-one/identity.public`
sed -i '88s/3a46f1bf30:0:76e66fab33e28549a62ee2064d1843273c2c300ba45c3f20bef02dbad225723bb59a9bb4b13535730961aeecf5a163ace477cceb0727025b99ac14a5166a09a3/'$identity'/' ./mkworld.cpp
sed -i '89s#185.180.13.82/9993#'$addr'#g' ./mkworld.cpp
sed -i '90s/roots.back/\/\/roots.back/' ./mkworld.cpp
#2identity=输入你的

source ./build.sh
sleep 8s
./mkworld
mv ./world.bin ./planet
cp -f ./planet /home/zerotier/etc/zt-mkworld
cp -f ./planet /home/zerotier/opt/key-networks/ztncui/etc/httpfs
cp -f ./planet /home/zerotier/var/lib/zerotier-one
cd && cd /root/planet/
docker cp patch.sh ztncui:/tmp
docker exec -it ztncui bash /tmp/patch.sh
docker restart ztncui
sleep 5s
rm -f /root/planet
rm -f /root/planet&moos.tar.gz